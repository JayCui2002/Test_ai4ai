import torch
from src.config import Config
from src.models.bert_model import get_model_and_tokenizer
from src.data.data_loader import load_data
from src.training.trainer import Trainer
from src.training.evaluator import Evaluator
from src.utils.metrics import calculate_mse

def main():
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")
    
    # 初始化模型和tokenizer
    print("加载模型和tokenizer...")
    model, tokenizer = get_model_and_tokenizer()
    model.to(device)
    
    # 加载数据
    print("加载数据...")
    train_loader, val_loader = load_data(tokenizer)
    
    # 初始化优化器
    optimizer = torch.optim.AdamW(model.parameters(), lr=Config.LEARNING_RATE)
    
    # 训练模型
    print("开始训练...")
    trainer = Trainer(model, optimizer, device)
    evaluator = Evaluator(model, device)
    
    best_mse = float('inf')
    
    for epoch in range(Config.NUM_EPOCHS):
        # 训练一个epoch
        avg_loss = trainer.train_epoch(train_loader, epoch, Config.NUM_EPOCHS)
        print(f'第 {epoch + 1}/{Config.NUM_EPOCHS} 轮平均损失: {avg_loss:.4f}')
        
        # 在验证集上评估
        predictions, actual_values = evaluator.evaluate(val_loader)
        mse = calculate_mse(predictions, actual_values)
        print(f'验证集均方误差: {mse:.4f}')
        
        # 保存最佳模型
        if mse < best_mse:
            best_mse = mse
            print(f"发现更好的模型，MSE: {mse:.4f}")
            model.save_pretrained(Config.MODEL_SAVE_PATH)
            tokenizer.save_pretrained(Config.MODEL_SAVE_PATH)
    
    print(f"训练完成！最佳MSE: {best_mse:.4f}")

if __name__ == "__main__":
    main() 