import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader
from .dataset import CustomDataset
from ..config import Config

def load_data(tokenizer):
    # 读取数据
    df = pd.read_csv(Config.DATA_PATH)
    
    # 获取特征列数据
    texts = df[Config.TEXT_COLUMNS].values
    
    # 获取标签列数据
    labels = df[Config.LABEL_COLUMN].values
    
    # 分割训练集和验证集
    train_texts, val_texts, train_labels, val_labels = train_test_split(
        texts, labels, test_size=0.2, random_state=42
    )
    
    # 创建数据集
    train_dataset = CustomDataset(
        train_texts, 
        train_labels,
        tokenizer,
        Config.MAX_LENGTH
    )
    
    val_dataset = CustomDataset(
        val_texts,
        val_labels,
        tokenizer,
        Config.MAX_LENGTH
    )
    
    # 创建数据加载器
    train_loader = DataLoader(
        train_dataset,
        batch_size=Config.BATCH_SIZE,
        shuffle=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=Config.BATCH_SIZE,
        shuffle=False
    )
    
    return train_loader, val_loader 