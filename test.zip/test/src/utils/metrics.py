import numpy as np

def calculate_mse(predictions, actual_values):
    return np.mean((predictions - actual_values) ** 2) 