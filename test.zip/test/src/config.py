class Config:
    # 模型相关
    MODEL_NAME = "bert-base-uncased"
    NUM_LABELS = 1
    
    # 数据相关
    DATA_PATH = "data/your_data.csv"
    
    # 选择要使用的特征列（选择与薪资相关的重要特征）
    TEXT_COLUMNS = [
        "MainBranch",          # 开发者类型
        "Employment",          # 就业状态
        "RemoteWork",          # 远程工作情况
        "EdLevel",             # 教育水平
        "YearsCode",          # 编程年限
        "YearsCodePro",       # 专业编程年限
        "DevType",            # 开发者职位
        "OrgSize",            # 公司规模
        "Country",            # 国家
        "LanguageHaveWorkedWith"  # 使用的编程语言
    ]
    
    # 预测目标列
    LABEL_COLUMN = "CompTotal"  # 年度总薪资
    
    # 模型参数
    MAX_LENGTH = 512
    BATCH_SIZE = 16
    LEARNING_RATE = 2e-5
    NUM_EPOCHS = 3
    TEST_SIZE = 0.2
    RANDOM_STATE = 42
    
    # 输出相关
    MODEL_SAVE_PATH = "outputs/trained_models"

# 确保导出 Config 类
__all__ = ['Config']