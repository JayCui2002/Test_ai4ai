import torch
import numpy as np
from tqdm import tqdm

class Evaluator:
    def __init__(self, model, device):
        self.model = model
        self.device = device
    
    def evaluate(self, val_loader):
        self.model.eval()
        predictions = []
        actual_values = []
        
        with torch.no_grad():
            for batch in tqdm(val_loader, desc='评估中'):
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels'].to(self.device)
                
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask
                )
                
                predictions.extend(outputs.logits.cpu().numpy().flatten())
                actual_values.extend(labels.cpu().numpy().flatten())
        
        return np.array(predictions), np.array(actual_values) 