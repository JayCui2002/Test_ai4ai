from transformers import AutoTokenizer, AutoModelForSequenceClassification
from ..config import Config

def get_model_and_tokenizer():
    tokenizer = AutoTokenizer.from_pretrained(Config.MODEL_NAME)
    model = AutoModelForSequenceClassification.from_pretrained(
        Config.MODEL_NAME,
        num_labels=Config.NUM_LABELS
    )
    return model, tokenizer 